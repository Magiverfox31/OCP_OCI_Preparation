
# OpenShift Agent-Based Precheck Ansible Project

Run:
ansible-playbook -i inventory/hosts.ini playbooks/precheck.yml

Customize DNS records and commands in group_vars/all.yml.
