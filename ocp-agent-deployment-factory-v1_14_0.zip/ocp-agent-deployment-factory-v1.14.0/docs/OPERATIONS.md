# Operator runbook — Oracle Linux 9

From the extracted project root, with approved DNF repositories and sudo rights:

```bash
sudo dnf install -y python3 ansible-core
ansible-playbook playbooks/dependencies.yml --ask-become-pass
```

Install an approved `openshift-install` binary matching the target OCP release separately and confirm `openshift-install version`. Ensure `python3 -c 'import yaml, jinja2'` succeeds.

1. Fill in the four `inventory/*.yml` files (`cluster`, `nodes`, `network`, `infrastructure`) and, if you need custom manifests, put them in `openshift/`. In `nodes.yml` set the shared values once under `node_defaults` (NIC name, root disk) and add each host with only `name`, `ip` and `mac`; gateway, DNS and NTP come from `network.yml` (see [INVENTORY_REFERENCE.md](INVENTORY_REFERENCE.md)). Put the pull secret and SSH public key in `secret/<cluster-name>/pull-secret.json` and `secret/<cluster-name>/ssh-key.pub` (`chmod 700` the folder, `chmod 600` the files); they are not set in `cluster.yml`. Never paste secret text into any inventory file or into a chat.
2. **Testing phase (optional but recommended).** Check `testing/urls.yml` and `testing/dns_f5.yml` (proxy for the bastion, F5 on/off). If you enabled the F5 REST audit (`f5_checks.rest`), export the read-only password first: `export F5_PASSWORD=...` (or use `password_file`). Run `ansible-playbook playbooks/preflight.yml`: it runs every check without stopping at the first failure and prints a PASSED/WARNINGS/FAILED summary (also saved in `work/preflight-<time>.log`). Fix the FAILED items and run it again until it is clean (see [PREFLIGHT.md](PREFLIGHT.md), [NETWORK_VALIDATION.md](NETWORK_VALIDATION.md)). `playbooks/netcheck.yml` runs only the DNS/F5 part.
3. **Phase 2 - configuration files.** Run `ansible-playbook playbooks/prepare.yml --ask-become-pass`. It validates the inventory and creates the configs (no connectivity tests) in `work/<cluster>/<run-id>/review/`.
4. Read `<cluster>-install-config.yaml`, `<cluster>-agent-config.yaml`, `<cluster>-image_metadata.json` and any `<cluster>-openshift-<file>` manifests there. Check that every `hostname` is the fully qualified name you expect (`<name>.<cluster>.<base_domain>` unless you set `cluster.node_domain`). Check addresses, host roles, MACs, the interface name, `mtu` and `rootDeviceHints` on every host, `minimalISO` (`true` means each node downloads the rootfs at boot), `additionalNTPSources`, the `proxy:` section and, for a disconnected install, `imageContentSources` and `additionalTrustBundle`. **Edit the files in `review/` if you need to** (only there; an untouched copy is in `generated/`).
5. Run `ansible-playbook playbooks/approve.yml -e run_id=<run-id>` when the files are final. It checks they still parse, copies them to `installer/`, prints a diff of your edits (no secrets) and records the approval. If it refuses a file, fix it and run approve again.
6. **Phase 3 - image.** Optionally set `cluster.image_build.proxy` in `cluster.yml` (`inherit`, `cluster`, `none`) before running `ansible-playbook playbooks/build.yml --ask-become-pass`. It creates the ISO, QCOW2 and `master_node_image.oci`.
7. Validate the image against OCI import and boot requirements **before production use**.
8. Run `ansible-playbook playbooks/archive.yml` to copy/verify the backup and reset the active inventory and testing settings.

If `build` fails, fix the cause and run `build.yml` again; installer inputs are restored from the approved review files. If you edit a review file after approving, `build` stops; run `approve` again. For rejection: `ansible-playbook playbooks/discard.yml -e run_id=<run-id>`; update inventory and prepare again. An interrupted build may still need manual inspection of its working directory.

**Warning:** `archive` resets the active inventory (so run `playbooks/netcheck.yml` with `tcp_probe: "require"` after the nodes are up and *before* archive if you want a live load-balancer check) after a verified archive; keep a second secure backup of critical inputs. One active run per checkout; parallel cluster builds require separate checkouts.

## Troubleshooting

- `dnf` fails: inspect `sudo dnf repolist`, repositories and proxy. A failure on a *required* package (python3, PyYAML, Jinja2, qemu-img, nmstate, tar, gzip) stops the run; a failure on an *optional* one (curl, bind-utils, nmap-ncat, iproute, openssl, python3-pip) only prints a note.
- A tool is missing or blocked (ping, dig, curl, nc): the factory never uses ping, and uses built-in Python DNS/HTTP clients when `dig`/`curl` are absent. The line `NETCHECK tools:` (and `(client: ...)` in the preflight summary) shows which one ran. If UDP/53 is blocked, the resolver gets a `WARN` and is checked over TCP. Manual alternatives are in [TOOLS_AND_FALLBACKS.md](TOOLS_AND_FALLBACKS.md).
- Python import fails: check `python3-pyyaml` and `python3-jinja2` availability.
- Installer missing/mismatched: check `command -v openshift-install` and `openshift-install version`.
- DNS/F5 check fails: each `FAIL` line names the record or virtual server and the reason. `REFUSED` = the Infoblox allow-query ACL/views do not permit the bastion address; `NXDOMAIN` = record missing; `got X, expected Y` = wrong address; `SERVFAIL` = resolver/zone problem; `no reply` = routing or firewall. F5 `missing control-plane nodes` = the pool lacks inventory nodes; `no virtual server` = no VIP:port destination on the BIG-IP; HTTP 401/403 = bad credentials or a role that cannot read LTM objects. Details in [NETWORK_VALIDATION.md](NETWORK_VALIDATION.md). Run `ansible-playbook playbooks/netcheck.yml` to re-test without creating a run.
- Several inventory errors at once: run `ansible-playbook playbooks/preflight.yml` first. It lists every inventory problem (file, field, value), checks the tools, URLs and DNS, and prints a PASSED/WARNINGS/FAILED summary, also saved in `work/preflight-<time>.log`.
- Preflight fails: each blocked URL is listed with the curl error (`Could not resolve host` = DNS, `timed out` = firewall, `SSL certificate problem` = TLS inspection; set `preflight.ca_bundle` or `proxy` in `testing/urls.yml`). Fix the network path or remove a URL you intentionally do not use from `testing/urls.yml`.
- Validation error about overlapping networks, `host_prefix`, or proxy: fix `inventory/network.yml` (`cluster_network`, `service_network` and `machine_network` must not overlap; proxy URLs must be `http://`).
- `nodes.yml` error (`missing "mac"`, `unknown key(s)`, `not inside network.machine_network`, `no interface`, `Duplicate host`): the message names the host and the problem; fix `inventory/nodes.yml` (or `network.yml` for the machine network and NTP) and run prepare again.
- Approve refuses a file: the message names the file and the problem (YAML syntax with line/column, renamed `metadata.name`, wrong `kind`, missing `rendezvousIP`/`hosts`/`pullSecret`). Fix the file in `review/` and run approve again. If the inventory changed since prepare, discard and prepare again.
- `ocp_version` rejected: quote it (`"4.18"`), use 4.18 or later, and make sure `openshift-install version` reports the same minor (and patch, if you gave one).
- `openshift/ manifests` error: the message names each bad file (extension, YAML syntax with line and column, missing `apiVersion`/`kind`, subfolder, symlink).
- Build says the reviewed file changed after approval: you edited `review/` after approving; run approve again (or discard and prepare again).
- Disconnected install (`cluster.mirror.enabled: true`) fails to pull images: check `mirror.registry` and `sources`, that `mirror.ca_bundle_file` is the CA that signed the registry certificate (it is written to `additionalTrustBundle` with policy `Always`), and that `cluster.release_image` points at the mirrored release.
- ISO/QCOW2 failure: inspect the preserved `work/<cluster>/<run-id>/` and verify disk space, installer logs and `qemu-img info`.
- Node boots the image but cannot continue and `minimalISO` is `true`: the node subnet cannot reach the rootfs download URL. Allow it (check the node subnet's routes, NSGs and proxy/firewall rules) or set `cluster.minimal_iso: false` and rebuild.
- Build stops with `OCI archive verification failed` or an `image_metadata.json` error: the template is invalid JSON or the archive contents differ from the expected two files; fix `templates/image_metadata.json` and re-prepare.
- OCI boot failure: image format alone is insufficient; validate OCI image import/firmware requirements.

See [BASTION_PREREQUISITES.md](BASTION_PREREQUISITES.md), [INVENTORY_REFERENCE.md](INVENTORY_REFERENCE.md), [NETWORK_VALIDATION.md](NETWORK_VALIDATION.md) and [ARTIFACTS_AND_BACKUPS.md](ARTIFACTS_AND_BACKUPS.md).
