# OCP Agent Deployment Factory v1.2
Stages:
1. Validation
2. Config/ISO/QCOW2
3. Deployment (future)
