Validation -> Review -> Approval -> ISO -> QCOW2
