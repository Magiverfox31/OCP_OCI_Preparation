Run 01-preflight -> 03-generate-configs -> 04-review-configs -> 05-build-agent-iso
